import json
import pandas as pd
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--results_dir", type=str, required=True)
args = parser.parse_args()

# Load JSONs
with open(f"{args.results_dir}/results_of_iteration.json", "r") as f:
    results = json.load(f)

with open(f"{args.results_dir}/selected_ids_per_iteration.json", "r") as f:
    selected = json.load(f)

rows = []

for it, values in results.items():
    if not it.isdigit():  # skip metadata keys like 'last_iteration'
        continue
    
    row = {"iteration": int(it)}
    row["data_percent"] = values["data_percent"]
    row["labeled_size"] = values["total_train_samples"]
    row["test_acc"] = values["test_results"]["acc"]
    row["test_f1"] = values["test_results"]["f1"]
    row["val_acc"] = values["val_results"]["acc"]
    row["val_f1"] = values["val_results"]["f1"]
    row["annotated_ids"] = selected[it]
    rows.append(row)

df = pd.DataFrame(rows)
df.sort_values("iteration", inplace=True)

df.to_csv(f"{args.results_dir}/active_learning_results.csv", index=False)

print(f"Saved CSV to {args.results_dir}/active_learning_results.csv")
