import os
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

# Paths
root = Path(".")
datasets_fr = root / "data" / "DatasetsFR"
colorado_dir = root / "data" / "COLORADO"

train_csv = datasets_fr / "TRAIN_0_Colorado_wildfires_binary.csv"
test_csv  = datasets_fr / "TEST_0_Colorado_wildfires_binary.csv"

print("Train CSV:", train_csv)
print("Test  CSV:", test_csv)

# Make sure output dir exists
colorado_dir.mkdir(parents=True, exist_ok=True)

# Load CSVs
train_df = pd.read_csv(train_csv)
test_df  = pd.read_csv(test_csv)

# We assume:
#   - text column: "text"
#   - label column: "Informativeness" (0/1)
if "text" not in train_df.columns:
    raise ValueError("Expected a 'text' column in TRAIN CSV (you renamed Tweet_Text -> text earlier).")

if "Informativeness" not in train_df.columns:
    raise ValueError("Expected 'Informativeness' column (0/1) in TRAIN CSV.")

def to_lists(df):
    X = df["text"].astype(str).tolist()
    y = df["Informativeness"].astype(int).astype(str).tolist()  # -> "0"/"1"
    return X, y

X_full, y_full = to_lists(train_df)
X_test, y_test = to_lists(test_df)

print(f"Full train size: {len(X_full)}")
print(f"Test size:       {len(X_test)}")

# Split train into train/dev (10% dev), with fixed seed 42 to match Sst2Processor logic
X_train, X_dev, y_train, y_dev = train_test_split(
    X_full,
    y_full,
    test_size=0.1,
    random_state=42,
    stratify=y_full,
)

print(f"Train size: {len(X_train)}")
print(f"Dev size:   {len(X_dev)}")

# Save in the format Sst2Processor expects: [X_list, y_list]
with open(colorado_dir / "train_42.json", "w") as f:
    json.dump([X_train, y_train], f)

with open(colorado_dir / "dev_42.json", "w") as f:
    json.dump([X_dev, y_dev], f)

with open(colorado_dir / "test.json", "w") as f:
    json.dump([X_test, y_test], f)

print("\nWrote:")
print(colorado_dir / "train_42.json")
print(colorado_dir / "dev_42.json")
print(colorado_dir / "test.json")
