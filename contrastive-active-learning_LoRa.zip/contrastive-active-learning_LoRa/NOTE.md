# Contrastive Active Learning – Python 3.11 Environment & Fix Guide

This document explains **exactly how to run the Contrastive Active Learning (CAL)** repository on:

* **macOS iMac 2017 (CPU-only)**
* **Lab machine with GPU + CUDA**

The original project was built for:

* Python **3.7**
* PyTorch **1.3–1.9**
* Transformers **3.1.0**

This guide updates everything to:

* Python **3.11**
* PyTorch **2.x**
* Transformers **4.x**

Including **all the fixes required to make CAL work** with modern libraries.

---

## 1. Conda Environment (Shared on CPU & GPU)

```bash
conda create -n cal311 python=3.11
conda activate cal311
```

You should see:

```
(cal311)
```

---

## 2. iMac (CPU-Only) Setup

Install CPU-only PyTorch:

```bash
conda install pytorch torchvision torchaudio cpuonly -c pytorch
```

Install remaining packages:

```bash
pip install "transformers>=4.40" "datasets>=2.0" scikit-learn tqdm \
            matplotlib seaborn pandas sentencepiece "protobuf==3.20.*"
```

---

## 3. Lab Machine (GPU + CUDA)

Create the same environment:

```bash
conda create -n cal311 python=3.11
conda activate cal311
```

Install PyTorch with CUDA (example: CUDA 12.1):

```bash
conda install pytorch torchvision torchaudio pytorch-cuda=12.1 \
              -c pytorch -c nvidia
```

Install additional libraries:

```bash
pip install "transformers>=4.40" "datasets>=2.0" scikit-learn tqdm \
            matplotlib seaborn pandas sentencepiece "protobuf==3.20.*"
```

If CUDA version differs, adjust:

```
pytorch-cuda=XX.X
```

---

## 4. Downloading Datasets

From the repository root:

```bash
bash get_data.sh
```

If QQP/QNLI fail due to `sys_config`, run:

```bash
PYTHONPATH=. python utilities/download_glue.py
```

---

## 5. Required Code Fixes (Python 3.11 + Transformers 4.x)

To run CAL on modern Python/Transformers, **three files must be patched**.

---

### A. Fix in `acquisition/cal.py`

Remove the deprecated import:

```python
# DELETE this line
from sklearn.neighbors.dist_metrics import DistanceMetric
```

Remove any use of:

```
DistanceMetric.get_metric(...)
```

CAL already gets distances from `KNeighborsClassifier`.

---

### B. Fix in `utilities/metrics.py`

Replace removed sklearn function:

**Old (broken):**

```python
from sklearn.metrics import calinski_harabaz_score
```

**New (working):**

```python
from sklearn.metrics import calinski_harabasz_score
calinski_harabaz_score = calinski_harabasz_score
```

---

### C. **Critical Fix** in `utilities/trainers.py` (my_evaluate)

Transformers 4.x changed BERT output format, making the old code crash with:

```
TypeError: mean() ... got (str, dim=int)
```

Replace the old embedding code with:

```python
# Forward pass through classifier
outputs = model(**inputs)
labels = inputs.pop("labels", None)

# Extract BERT embeddings (Transformers 4.x compatible)
if hasattr(args, "acquisition") or return_cls or return_mean_output or return_mean_embs:
    bert_outputs = model.bert(
        input_ids=inputs["input_ids"],
        attention_mask=inputs["attention_mask"],
        token_type_ids=inputs.get("token_type_ids", None),
        return_dict=True,
        output_hidden_states=False,
    )

    sequence_output = bert_outputs.last_hidden_state       # [B, L, H]
    bert_output_cls = bert_outputs.pooler_output           # [B, H]

    if return_mean_output or return_cls:
        bert_mean_output = torch.mean(sequence_output, dim=1)

    if return_mean_embs:
        bert_input = model.bert.embeddings(inputs["input_ids"])
        bert_mean_input = torch.mean(bert_input, dim=1)

# Loss + logits
tmp_eval_loss, logits = outputs[:2]
```

This fix is **mandatory** for CAL to work with transformers >= 4.0.

---

## 6. Running Experiments

### SST-2

```bash
python run_al.py --dataset_name sst-2 --acquisition cal
```

### IMDB

```bash
python run_al.py --dataset_name imdb --acquisition cal
```

### DBPEDIA

1. Download DBPEDIA manually into:

```
data/DBPEDIA/
```

2. Run:

```bash
python run_al.py --dataset_name dbpedia --acquisition cal
```

---

## 7. VS Code Setup (Optional but Recommended)

1. Press **Cmd/Ctrl + Shift + P**
2. Choose **Python: Select Interpreter**
3. Select **Python 3.11 (cal311)**

---

## 8. Final Notes

* iMac CPU-only training is slow → use GPU when possible
* All sklearn + transformers + PyTorch incompatibilities are now fixed
* CAL repository now runs correctly under:

  * Python **3.11**
  * PyTorch **2.x**
  * Transformers **4.x**

All acquisition functions (CAL, ALPS, BALD, BADGE, Entropy, etc.) run normally.

---

**End of File**
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
NEW task:


Colorado Dataset Integration — Summary of All Modifications

Prepared the dataset

Created prepare_colorado.py to convert the raw CSV into a clean binary dataset.

Mapping: “related and informative” → 0, everything else → 1.

Kept all original columns.

Output files saved to:
data/DatasetsFR/TRAIN_0_Colorado_wildfires_binary.csv
data/DatasetsFR/TEST_0_Colorado_wildfires_binary.csv

Created GLUE-style files

Created prepare_colorado_glue.py to convert cleaned CSVs into GLUE format.

Generated three JSON files:
data/COLORADO/train_42.json
data/COLORADO/dev_42.json
data/COLORADO/test.json

Each JSON file contains two lists: X_list and y_list.

Added a Colorado processor

Edited utilities/preprocessors.py by creating class ColoradoProcessor.

Registered it:
processors["colorado"] = ColoradoProcessor
output_modes["colorado"] = "classification"

Patched get_glue_dataset()

Edited utilities/data_loader.py.

Added a special case:
if task == "colorado": load the JSON files and return X, y.

This bypasses the missing GLUE .tsv files.

Patched get_glue_tensor_dataset()

Also in utilities/data_loader.py.

Added a Colorado block to:

load JSON files,

build InputExamples,

convert to features,

return a TensorDataset.

This prevents index errors during active learning iterations.

Added “colorado” to configuration

Updated sys_config.py:
available_datasets += ["colorado"]

Final test

Ran:
python run_al.py --dataset_name colorado --acquisition cal

System successfully:
loads Colorado dataset,
builds train/dev/test tensors,
starts iteration training,
no missing file errors,
no index out-of-range errors.



The dataset is first split into train, validation, and test sets. Active Learning then runs in multiple iterations (loops) — each iteration selects a new batch of unlabeled samples to label. At the start, a small percentage of the training data (e.g., 1%) is chosen as the initial labeled set. In every AL iteration, the model (BERT) is trained for several epochs (typically 3) on the currently labeled data, and its performance is checked on the validation set. After training, CAL scores all remaining unlabeled examples using contrastive similarity and uncertainty, then selects a new batch of the most informative samples (e.g., 2% of the dataset) to be added to the labeled pool. This process repeats for as many AL loops as needed until the total annotation budget (e.g., 15% of the dataset) is reached. In short: train for a few epochs → select new data → retrain → repeat.