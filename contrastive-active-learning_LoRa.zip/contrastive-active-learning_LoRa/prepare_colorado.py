import pandas as pd
from pathlib import Path

# Paths (adjust if needed)
root = Path(".")
data_dir = root / "data" / "DatasetsFR"

train_path = data_dir / "TRAIN_0_Colorado_wildfires.csv"
test_path  = data_dir / "TEST_0_Colorado_wildfires.csv"

print("DEBUG train_path =", train_path)
print("DEBUG CWD       =", Path(".").resolve())

train_df = pd.read_csv(train_path)
test_df  = pd.read_csv(test_path)

def convert_informativeness(df):
    # Remove auto index column if it exists
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])

    # Remove old 'label' column if it exists
    if "label" in df.columns:
        df = df.drop(columns=["label"])

    # Convert text classes to 0/1 directly INTO the same column
    def map_informativeness(val):
        if isinstance(val, str) and val.strip().lower() == "related and informative":
            return 0
        else:
            return 1

    df["Informativeness"] = df["Informativeness"].apply(map_informativeness)

    # (Optional) rename Tweet_Text → text
    if "Tweet_Text" in df.columns:
        df = df.rename(columns={"Tweet_Text": "text"})

    # Keep ALL columns in original order except removed ones
    return df

# Create processed versions
train_bin = convert_informativeness(train_df)
test_bin  = convert_informativeness(test_df)

# Confirm column names
print("\nColumns in train_bin:", train_bin.columns.tolist())
print("Columns in test_bin:", test_bin.columns.tolist())

# Print updated label distributions
print("\nTrain Informativeness distribution:")
print(train_bin["Informativeness"].value_counts())
print("\nTest Informativeness distribution:")
print(test_bin["Informativeness"].value_counts())

# Save final processed CSVs
train_bin.to_csv(data_dir / "TRAIN_0_Colorado_wildfires_binary.csv", index=False)
test_bin.to_csv(data_dir / "TEST_0_Colorado_wildfires_binary.csv", index=False)

print("\nSaved processed files:")
print(data_dir / "TRAIN_0_Colorado_wildfires_binary.csv")
print(data_dir / "TEST_0_Colorado_wildfires_binary.csv")
