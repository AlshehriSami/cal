import pandas as pd
from pathlib import Path

def load_colorado_binary(data_dir):
    """
    Load the Colorado wildfires dataset (binary informativeness).

    Expects:
      data_dir / 'DatasetsFR' / 'TRAIN_0_Colorado_wildfires_binary.csv'
      data_dir / 'DatasetsFR' / 'TEST_0_Colorado_wildfires_binary.csv'

    Returns:
      X_train: list[str]
      y_train: list[int]
      X_test:  list[str]
      y_test:  list[int]
    """
    data_dir = Path(data_dir)
    dataset_dir = data_dir / "DatasetsFR"

    train_path = dataset_dir / "TRAIN_0_Colorado_wildfires_binary.csv"
    test_path  = dataset_dir / "TEST_0_Colorado_wildfires_binary.csv"

    train_df = pd.read_csv(train_path)
    test_df  = pd.read_csv(test_path)

    # Use the processed columns
    X_train = train_df["text"].astype(str).tolist()
    y_train = train_df["Informativeness"].astype(int).tolist()

    X_test = test_df["text"].astype(str).tolist()
    y_test = test_df["Informativeness"].astype(int).tolist()

    return X_train, y_train, X_test, y_test
